package ProjetoHospital;

public class Paciente {

    private String cpf;
    private String nome;
    private int idade;
    private String sexo;
    private String endereco;
    private String telefone;

    public Paciente(String cpf, String nome, int idade, String sexo, String endereco, String telefone) {
        this.cpf = cpf;
        this.nome = nome;
        this.idade = idade;
        this.endereco = endereco;
        this.telefone = telefone;
        this.sexo = sexo;
    }

    Paciente() {
    }

    void mostraInfo(){
        System.out.println("CPF : " + cpf);
        System.out.println("NOME: " + nome);
        System.out.println("IDADE: " + idade);
        System.out.println("ENDEREÇO: " + endereco);
        System.out.println("TELEFONE: " + telefone);
        System.out.println("SEXO: " + sexo);
    }

    public String getCpf() {
        return cpf;
    }

    public String getNome() {
        return nome;
    }

    public int getIdade() {
        return idade;
    }

    public String getEndereco() {
        return endereco;
    }

    public String getSexo() {
        return sexo;
    }

    public String getTelefone() {
        return telefone;
    }

}
